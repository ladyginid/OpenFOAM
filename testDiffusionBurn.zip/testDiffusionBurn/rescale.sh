#transformPoints -scale '(1e-3 1e-3 1e-3)'
surfaceConvert in.stl out.stl -clean -scale 0.001
