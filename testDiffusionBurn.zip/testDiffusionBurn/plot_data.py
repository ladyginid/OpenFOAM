#### import the simple module from the paraview
from paraview.simple import *
import os
#### disable automatic camera reset on 'Show'
paraview.simple._DisableFirstRenderCameraReset()

rootdir=os.getcwd()
print(rootdir)

# get active source.
# create a new 'OpenFOAMReader'
foamfoam = OpenFOAMReader(FileName=rootdir+'/foam.foam')
foamfoam.LabelSize = '64-bit'
foamfoam.MeshRegions = ['internalMesh']

# get active view
renderView1 = GetActiveViewOrCreate('RenderView')
renderView1.AxesGrid.Visibility=1
renderView1.AxesGrid.XLabelFontSize=24
renderView1.AxesGrid.YLabelFontSize=24
renderView1.AxesGrid.ZLabelFontSize=24


## reset view to fit data
renderView1.ResetCamera()
renderView1.InteractionMode = '2D'
#renderView1.CameraPosition = [0.6,  0.0, 0.3]
#renderView1.CameraFocalPoint = [0.45, 0.0, 0.3]
#renderView1.CameraViewUp = [0.0, 0.0, 1.0]
renderView1.CameraParallelScale = 0.0075

# create a new 'Slice'
slice1 = Slice(Input=foamfoam)
slice1.SliceType = 'Plane'
slice1.SliceOffsetValues = [0.0]

# init the 'Plane' selected for 'SliceType'
slice1.SliceType.Origin = [0.0, 0.0, 0.0]

# Properties modified on slice1.SliceType
slice1.SliceType.Normal = [0.0, 0.0, 1.0]

# Properties modified on slice1.SliceType
slice1.SliceType.Normal = [0.0, 0.0, 1.0]

# get color transfer function/color map for 'p'
pLUT = GetColorTransferFunction('T')
pLUT.ColorSpace = 'HSV'
pLUT.UseBelowRangeColor = 1
pLUT.BelowRangeColor = [0.0, 0.0, 0.0]
pLUT.UseAboveRangeColor = 1
pLUT.AboveRangeColor = [1.0, 1.0, 1.0]

pLUT.RGBPoints = [298., 0.0, 0.0, 1.0, 800., 1.0, 0.0, 0.0]
scalarbar = GetScalarBar(pLUT,renderView1)
scalarbar.Position = [0.2,0.9]
scalarbar.Orientation = 'Horizontal'
scalarbar.ScalarBarThickness = 2
scalarbar.ScalarBarLength = 0.33
scalarbar.TitleFontSize=5
scalarbar.LabelFontSize=5
scalarbar.CustomLabels=[298,400,500,600,700,800]
scalarbar.UseCustomLabels=True


# show data in view
slice1Display = Show(slice1, renderView1)
## trace defaults for the display properties.
slice1Display.Representation = 'Surface With Edges'
slice1Display.ColorArrayName = ['POINTS', 'T']
slice1Display.LookupTable = pLUT
#slice1Display.MapScalars = 1
#slice1Display.InterpolateScalarsBeforeMapping = 1
#slice1Display.Interpolation = 'Gouraud'

# hide data in view
Hide(foamfoam, renderView1)

# show color bar/color legend
slice1Display.SetScalarBarVisibility(renderView1, True)


 # create a new 'Plot Over Line'
plotOverLine1 = PlotOverLine(Input=slice1,
    Source='High Resolution Line Source')

# Properties modified on plotOverLine1.Source
plotOverLine1.Source.Point1 = [0.0, 0.00, 0.00]
plotOverLine1.Source.Point2 = [ 0.005, 0.00, 0.00]

################################################################################

#annotate time on a profile
#annTime = AnnotateTimeFilter(reader)

# update the view to ensure updated data information
renderView1.Update()
SetActiveSource(slice1)

tsteps = foamfoam.TimestepValues
tidx=0
for ts in tsteps:

    print("at time %e: "%(ts))
#    UpdatePipeline(ts)
    renderView1.ViewTime = ts
#    Render()
#    renderView1.Update()
    SetActiveSource(slice1)
    pLUT.RGBPoints = [298., 0.0, 0.0, 1.0, 800., 1.0, 0.0, 0.0]
    SaveScreenshot(rootdir+'/profile_%02d.png'%(tidx), renderView1, ImageResolution=[1400, 650],
                    FontScaling='Scale fonts proportionally',
                    OverrideColorPalette='',
                    StereoMode='No change',
                    TransparentBackground=0,
                    ImageQuality=100)

# set active source
    SetActiveSource(plotOverLine1)


    UpdatePipeline(ts)

    tval = '%d'%(ts*1e6) #in microseconds
    SaveData(rootdir + '/data_over_line_ts%s.csv'%(tval), proxy=plotOverLine1)

    tidx+=1


