#### import the simple module from the paraview
from paraview.simple import *
#### disable automatic camera reset on 'Show'
paraview.simple._DisableFirstRenderCameraReset()

# find source
slice1 = FindSource('Slice1')

# create a new 'Plot Over Line'
plotOverLine1 = PlotOverLine(Input=slice1,
    Source='High Resolution Line Source')

# init the 'High Resolution Line Source' selected for 'Source'
plotOverLine1.Source.Point1 = [-1.3234889800848443e-23, -0.004999999888241291, -0.004999999888241291]
plotOverLine1.Source.Point2 = [6.617444900424222e-24, 0.004999999888241291, 0.004999999888241291]

# find source
foamfoam = FindSource('foam.foam')

# Properties modified on plotOverLine1.Source
plotOverLine1.Source.Point1 = [0.0, 0.0, 0.0]
plotOverLine1.Source.Point2 = [0.0, 0.0, 0.004999999888241291]

# Properties modified on plotOverLine1.Source
plotOverLine1.Source.Point1 = [0.0, 0.0, 0.0]
plotOverLine1.Source.Point2 = [0.0, 0.0, 0.004999999888241291]

# get active view
renderView1 = GetActiveViewOrCreate('RenderView')
# uncomment following to set a specific view size
# renderView1.ViewSize = [1281, 556]

# get color transfer function/color map for 'p'
pLUT = GetColorTransferFunction('p')

# show data in view
plotOverLine1Display = Show(plotOverLine1, renderView1)
# trace defaults for the display properties.
plotOverLine1Display.Representation = 'Surface'
plotOverLine1Display.ColorArrayName = ['POINTS', 'p']
plotOverLine1Display.LookupTable = pLUT
plotOverLine1Display.OSPRayScaleArray = 'p'
plotOverLine1Display.OSPRayScaleFunction = 'PiecewiseFunction'
plotOverLine1Display.SelectOrientationVectors = 'U'
plotOverLine1Display.ScaleFactor = 0.0004999999888241291
plotOverLine1Display.SelectScaleArray = 'p'
plotOverLine1Display.GlyphType = 'Arrow'
plotOverLine1Display.GlyphTableIndexArray = 'p'
plotOverLine1Display.DataAxesGrid = 'GridAxesRepresentation'
plotOverLine1Display.PolarAxes = 'PolarAxesRepresentation'
plotOverLine1Display.GaussianRadius = 0.00024999999441206456
plotOverLine1Display.SetScaleArray = ['POINTS', 'p']
plotOverLine1Display.ScaleTransferFunction = 'PiecewiseFunction'
plotOverLine1Display.OpacityArray = ['POINTS', 'p']
plotOverLine1Display.OpacityTransferFunction = 'PiecewiseFunction'

# init the 'PiecewiseFunction' selected for 'OSPRayScaleFunction'
plotOverLine1Display.OSPRayScaleFunction.Points = [73662.8984375, 0.0, 0.5, 0.0, 122550.0, 1.0, 0.5, 0.0]

# init the 'PiecewiseFunction' selected for 'ScaleTransferFunction'
plotOverLine1Display.ScaleTransferFunction.Points = [73662.8984375, 0.0, 0.5, 0.0, 122550.0, 1.0, 0.5, 0.0]

# init the 'PiecewiseFunction' selected for 'OpacityTransferFunction'
plotOverLine1Display.OpacityTransferFunction.Points = [73662.8984375, 0.0, 0.5, 0.0, 122550.0, 1.0, 0.5, 0.0]

# Create a new 'Line Chart View'
lineChartView1 = CreateView('XYChartView')
lineChartView1.ViewSize = [636, 556]
lineChartView1.LeftAxisRangeMaximum = 6.66
lineChartView1.BottomAxisRangeMaximum = 6.66
lineChartView1.RightAxisRangeMaximum = 6.66
lineChartView1.TopAxisRangeMaximum = 6.66

# get layout
layout1 = GetLayout()

# place view in the layout
layout1.AssignView(2, lineChartView1)

# show data in view
plotOverLine1Display_1 = Show(plotOverLine1, lineChartView1)
# trace defaults for the display properties.
plotOverLine1Display_1.CompositeDataSetIndex = [0]
plotOverLine1Display_1.UseIndexForXAxis = 0
plotOverLine1Display_1.XArrayName = 'arc_length'
plotOverLine1Display_1.SeriesVisibility = ['dQ', 'H', 'H2', 'H2O', 'H2O2', 'HO2', 'N2', 'O', 'O2', 'OH', 'p', 'p_rgh', 'rho', 'T', 'U_Magnitude']
plotOverLine1Display_1.SeriesLabel = ['arc_length', 'arc_length', 'dQ', 'dQ', 'H', 'H', 'H2', 'H2', 'H2O', 'H2O', 'H2O2', 'H2O2', 'HO2', 'HO2', 'N2', 'N2', 'O', 'O', 'O2', 'O2', 'OH', 'OH', 'p', 'p', 'p_rgh', 'p_rgh', 'rho', 'rho', 'T', 'T', 'U_X', 'U_X', 'U_Y', 'U_Y', 'U_Z', 'U_Z', 'U_Magnitude', 'U_Magnitude', 'vtkValidPointMask', 'vtkValidPointMask', 'Points_X', 'Points_X', 'Points_Y', 'Points_Y', 'Points_Z', 'Points_Z', 'Points_Magnitude', 'Points_Magnitude']
plotOverLine1Display_1.SeriesColor = ['arc_length', '0', '0', '0', 'dQ', '0.89', '0.1', '0.11', 'H', '0.22', '0.49', '0.72', 'H2', '0.3', '0.69', '0.29', 'H2O', '0.6', '0.31', '0.64', 'H2O2', '1', '0.5', '0', 'HO2', '0.65', '0.34', '0.16', 'N2', '0', '0', '0', 'O', '0.89', '0.1', '0.11', 'O2', '0.22', '0.49', '0.72', 'OH', '0.3', '0.69', '0.29', 'p', '0.6', '0.31', '0.64', 'p_rgh', '1', '0.5', '0', 'rho', '0.65', '0.34', '0.16', 'T', '0', '0', '0', 'U_X', '0.89', '0.1', '0.11', 'U_Y', '0.22', '0.49', '0.72', 'U_Z', '0.3', '0.69', '0.29', 'U_Magnitude', '0.6', '0.31', '0.64', 'vtkValidPointMask', '1', '0.5', '0', 'Points_X', '0.65', '0.34', '0.16', 'Points_Y', '0', '0', '0', 'Points_Z', '0.89', '0.1', '0.11', 'Points_Magnitude', '0.22', '0.49', '0.72']
plotOverLine1Display_1.SeriesPlotCorner = ['arc_length', '0', 'dQ', '0', 'H', '0', 'H2', '0', 'H2O', '0', 'H2O2', '0', 'HO2', '0', 'N2', '0', 'O', '0', 'O2', '0', 'OH', '0', 'p', '0', 'p_rgh', '0', 'rho', '0', 'T', '0', 'U_X', '0', 'U_Y', '0', 'U_Z', '0', 'U_Magnitude', '0', 'vtkValidPointMask', '0', 'Points_X', '0', 'Points_Y', '0', 'Points_Z', '0', 'Points_Magnitude', '0']
plotOverLine1Display_1.SeriesLabelPrefix = ''
plotOverLine1Display_1.SeriesLineStyle = ['arc_length', '1', 'dQ', '1', 'H', '1', 'H2', '1', 'H2O', '1', 'H2O2', '1', 'HO2', '1', 'N2', '1', 'O', '1', 'O2', '1', 'OH', '1', 'p', '1', 'p_rgh', '1', 'rho', '1', 'T', '1', 'U_X', '1', 'U_Y', '1', 'U_Z', '1', 'U_Magnitude', '1', 'vtkValidPointMask', '1', 'Points_X', '1', 'Points_Y', '1', 'Points_Z', '1', 'Points_Magnitude', '1']
plotOverLine1Display_1.SeriesLineThickness = ['arc_length', '2', 'dQ', '2', 'H', '2', 'H2', '2', 'H2O', '2', 'H2O2', '2', 'HO2', '2', 'N2', '2', 'O', '2', 'O2', '2', 'OH', '2', 'p', '2', 'p_rgh', '2', 'rho', '2', 'T', '2', 'U_X', '2', 'U_Y', '2', 'U_Z', '2', 'U_Magnitude', '2', 'vtkValidPointMask', '2', 'Points_X', '2', 'Points_Y', '2', 'Points_Z', '2', 'Points_Magnitude', '2']
plotOverLine1Display_1.SeriesMarkerStyle = ['arc_length', '0', 'dQ', '0', 'H', '0', 'H2', '0', 'H2O', '0', 'H2O2', '0', 'HO2', '0', 'N2', '0', 'O', '0', 'O2', '0', 'OH', '0', 'p', '0', 'p_rgh', '0', 'rho', '0', 'T', '0', 'U_X', '0', 'U_Y', '0', 'U_Z', '0', 'U_Magnitude', '0', 'vtkValidPointMask', '0', 'Points_X', '0', 'Points_Y', '0', 'Points_Z', '0', 'Points_Magnitude', '0']

# update the view to ensure updated data information
renderView1.Update()

# update the view to ensure updated data information
lineChartView1.Update()

# save data
SaveData('/media/sf_cwbFoam/kinCWB/testSurfaceBurn/data_over_line.csv', proxy=plotOverLine1)

#### saving camera placements for all active views

# current camera placement for renderView1
renderView1.CameraPosition = [-0.015826892602351268, 0.0, 0.0]
renderView1.CameraFocalPoint = [1e-20, 0.0, 0.0]
renderView1.CameraParallelScale = 0.01062475043033894

#### uncomment the following to render all views
# RenderAllViews()
# alternatively, if you want to write images, you can use SaveScreenshot(...).