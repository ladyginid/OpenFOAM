foamListTimes -rm
rm -r constant/polyMesh
